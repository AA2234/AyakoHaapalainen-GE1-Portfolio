namespace UnityEditor.ShaderGraph
{
    class TestNode : AbstractMaterialNode
    {
    }
}
