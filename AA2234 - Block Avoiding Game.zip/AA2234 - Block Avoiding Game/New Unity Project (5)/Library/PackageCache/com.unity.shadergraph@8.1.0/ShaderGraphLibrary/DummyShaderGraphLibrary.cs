// This file is only to force Unity to load the ShaderLibrary's hlsl files in visual studio project via asmdef file, so they can be browse.
class DummyShaderGraphLibrary
{

}
